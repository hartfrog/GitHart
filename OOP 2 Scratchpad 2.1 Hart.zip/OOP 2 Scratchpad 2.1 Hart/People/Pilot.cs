﻿namespace People
{
    /// <summary>
    /// The class which is used to represent a pilot.
    /// </summary>
    public class Pilot : Person
    {
    }
}