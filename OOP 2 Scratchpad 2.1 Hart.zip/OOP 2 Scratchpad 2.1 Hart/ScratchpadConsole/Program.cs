﻿using System;
using Airports;

namespace ScratchpadConsole
{
    /// <summary>
    /// The class which is used to manage interaction with the console.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    public class Program
    {
        /// <summary>
        /// Serves as the entry-point for the console application.
        /// </summary>
        /// <param name="args">Window commands.</param>
        public static void Main(string[] args)
        {
            Airport dfw = null;

            Console.Title = "Object Oriented Programming 2: Scratchpad";

            // Control break loop - to control the flow in the console.
            bool exit = false;

            while (!exit)
            {
                Console.Write("] ");

                string line = Console.ReadLine();

                // Array of strings.
                string[] commandWords = line.Split();

                switch (commandWords[0])
                {
                    case "exit":
                        exit = true;

                        break;
                    case "new":
                        dfw = new Airport();

                        break;
                    case "parking":
                        try
                        {
                            dfw.ParkingCost = decimal.Parse(commandWords[1]);
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Please enter a valid number for parking cost.");
                        }
                        catch (NullReferenceException)
                        {
                            Console.WriteLine("Please create an airport before setting its parking cost.");
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("Please enter a valid number for parking cost.");
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                            Console.WriteLine("Please enter a number between 0 and 100 for parking cost.");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }

                        break;

                    default:
                        Console.WriteLine("Invalid Command Entered");

                        break;
                }
            }
        }
    }
}
