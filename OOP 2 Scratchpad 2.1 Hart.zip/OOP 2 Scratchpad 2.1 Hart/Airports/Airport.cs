﻿using System;
using System.Collections.Generic;
using Airplanes;
using People;

namespace Airports
{
    /// <summary>
    /// The class which is used to represent an airport.
    /// </summary>
    public class Airport
    {
        /// <summary>
        /// A list of the airplanes currently located within the airport.
        /// </summary>
        private List<Airplane> airplanes = new List<Airplane>();

        /// <summary>
        /// A list of people.
        /// </summary>
        private List<Person> people = new List<Person>();

        /// <summary>
        /// The cost of parking.
        /// </summary>
        private decimal parkingCost;

        /// <summary>
        /// Gets or sets a list of the airplanes currently located within the airport.
        /// </summary>
        public List<Airplane> Airplanes
        {
            get
            {
                return this.airplanes;
            }

            set
            {
                this.airplanes = value;
            }
        }

        /// <summary>
        /// Gets an Ineumerable type person. 
        /// </summary>
        public List<Person> People
        {
            get
            {
                return this.people;
            }
        }

        /// <summary>
        /// Gets or sets the cost of parking.
        /// </summary>
        public decimal ParkingCost
        {
            get
            {
                return this.parkingCost;
            }

            set
            {
                // If value is in acceptable range.(Encapsulation).
                if (value >= 0 && value <= 100)
                {
                    this.parkingCost = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("ParkingCost", "Parking cost was out of range.");
                }
            }
        }

            /// <summary>
            /// Adds a person to the list of people.
            /// </summary>
            /// <param name="age">Person's age.</param>
            /// <param name="firstName">Person's name.</param>
            public void AddPerson(int age, string firstName)
        {
            Person person = new Person();

            person.Age = age;
            person.FirstName = firstName;

            this.people.Add(person);
        }

        /// <summary>
        /// Adds a person to the list of people.
        /// </summary>
        /// <param name="person">A person age.</param>
        public void AddPerson(Person person)
        {
            // Adds a person to the list.
            this.people.Add(person);
        }
    }
}