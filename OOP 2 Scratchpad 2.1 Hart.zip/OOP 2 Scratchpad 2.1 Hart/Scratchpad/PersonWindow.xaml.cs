﻿using System.Windows;
using People;

namespace Scratchpad
{
    /// <summary>
    /// Interaction logic for PersonWindow.xaml.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    public partial class PersonWindow : Window
    {       
        /// <summary>
        /// Initializes an instance of the Person class.
        /// </summary>
        private Person person;

        /// <summary>
        /// Initializes a new instance of the PersonWindow class.
        /// </summary>
        /// <param name="person">A person to add.</param>
        public PersonWindow(Person person)
        {
            this.person = person;
            this.InitializeComponent();
            
            this.ageTextBox.Text = this.person.Age.ToString();
            this.firstNameTextBox.Text = this.person.FirstName;
        }

        /// <summary>
        /// Sets the age of the person to the entered age from the person window.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void ageTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.person.Age = int.Parse(this.ageTextBox.Text);
        }

        /// <summary>
        /// Sets the name of the person to the entered name from the person window.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void firstNameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.person.FirstName = this.firstNameTextBox.Text;
        }

        /// <summary>
        /// Sets the behavior of the OK button.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }
    }
}
