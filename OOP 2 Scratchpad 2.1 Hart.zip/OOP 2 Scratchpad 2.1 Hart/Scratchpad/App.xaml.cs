﻿using System.Windows;

namespace Scratchpad
{
    /// <summary>
    /// Contains interaction logic for App.xaml.
    /// </summary>
    public partial class App : Application
    {
    }
}