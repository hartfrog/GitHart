﻿using System;
using System.Collections.Generic;
using Animals;
using BirthingRooms;
using BoothItems;
using MoneyCollectors;
using People;
using Reproducers;
using VendingMachines;

namespace Zoos
{
    /// <summary>
    /// The class which is used to represent a zoo.
    /// </summary>
    public class Zoo
    {
        /// <summary>
        /// A list of all animals currently residing within the zoo.
        /// </summary>
        private List<Animal> animals;

        /// <summary>
        /// The zoo's vending machine which allows guests to buy snacks for animals.
        /// </summary>
        private VendingMachine animalSnackMachine;

        /// <summary>
        /// The zoo's room for birthing animals.
        /// </summary>
        private BirthingRoom b168;

        /// <summary>
        /// The maximum number of guests the zoo can accommodate at a given time.
        /// </summary>
        private int capacity;

        /// <summary>
        /// A list of all guests currently visiting the zoo.
        /// </summary>
        private List<Guest> guests;

        /// <summary>
        /// The zoo's ladies' restroom.
        /// </summary>
        private Restroom ladiesRoom;

        /// <summary>
        /// The zoo's men's restroom.
        /// </summary>
        private Restroom mensRoom;

        /// <summary>
        /// The name of the zoo.
        /// </summary>
        private string name;

        /// <summary>
        /// The zoo's money collecting booth.
        /// </summary>
        private MoneyCollectingBooth ticketBooth;

        /// <summary>
        /// The zoo's information booth.
        /// </summary>
        private GivingBooth informationBooth;

        /// <summary>
        /// Initializes a new instance of the Zoo class.
        /// </summary>
        /// <param name="name">The name of the zoo.</param>
        /// <param name="capacity">The maximum number of guests the zoo can accommodate at a given time.</param>
        /// <param name="restroomCapacity">The capacity of the zoo's restrooms.</param>
        /// <param name="animalFoodPrice">The price of a pound of food from the zoo's animal snack machine.</param>
        /// <param name="ticketPrice">The price of an admission ticket to the zoo.</param>
        /// <param name="waterBottlePrice">The price of a water bottle the zoo.</param>
        /// <param name="attendant">The zoo's ticket booth attendant.</param>
        /// <param name="vet">The zoo's birthing room vet.</param>
        public Zoo(string name, int capacity, int restroomCapacity, decimal animalFoodPrice, decimal ticketPrice, decimal waterBottlePrice, Employee attendant, Employee vet)
        {
            this.animals = new List<Animal>();
            this.animalSnackMachine = new VendingMachine(animalFoodPrice, new MoneyBox());
            this.b168 = new BirthingRoom(vet);
            this.capacity = capacity;
            this.guests = new List<Guest>();
            this.informationBooth = new GivingBooth(attendant);
            this.ladiesRoom = new Restroom(restroomCapacity, Gender.Female);
            this.mensRoom = new Restroom(restroomCapacity, Gender.Male);
            this.name = name;
            this.ticketBooth = new MoneyCollectingBooth(attendant, ticketPrice, waterBottlePrice, new MoneyBox());            
        }

        /// <summary>
        /// Gets the list of animals.
        /// </summary>
        public IEnumerable<Animal> Animals
        {
            get
            {
                return this.animals as IEnumerable<Animal>;
            }            
        }

        /// <summary>
        /// Gets the list of guests.
        /// </summary>
        public IEnumerable<Guest> Guests
        {
            get
            {
                return this.guests as IEnumerable<Guest>;
            }
        }

        /// <summary>
        /// Gets the zoo's animal snack machine.
        /// </summary>
        public VendingMachine AnimalSnackMachine
        {
            get
            {
                return this.animalSnackMachine;
            }
        }

        /// <summary>
        /// Gets or sets the temperature of the zoo's birthing room.
        /// </summary>
        public double BirthingRoomTemperature
        {
            get
            {
                return this.b168.Temperature;
            }

            set
            {
                this.b168.Temperature = value;
            }
        }

        /// <summary>
        /// Gets the total weight of all animals in the zoo.
        /// </summary>
        public double TotalAnimalWeight
        {
            get
            {
                double totalWeight = 0;

                // Loop through the zoo's list of animals.
                foreach (Animal a in this.animals)
                {
                    // Add the current animal's weight to the total.
                    totalWeight += a.Weight;
                }

                return totalWeight;
            }
        }

        /// <summary>
        /// Creates a zoo and related objects.
        /// </summary>
        /// <returns>A new zoo.</returns>
        public static Zoo NewZoo()
        {
            // Create an instance of the Zoo class.
            Zoo comoZoo = new Zoo("Como Zoo", 1000, 4, 0.75m, 15.00m, 3.00m, new Employee("Sam", 42), new Employee("Flora", 98));

            // Set the initial money balance of the animal snack machine.
            comoZoo.AnimalSnackMachine.AddMoney(42.75m);

            // Define an animal variable.
            Animal animal;

            // Create Dolly.
            animal = new Dingo("Dolly", 4, 35.3, Gender.Female);

            // Make Dolly pregnant.
            animal.MakePregnant();

            // Add Dolly to the zoo's animal list.
            comoZoo.AddAnimal(animal);

            // Create Dixie.
            animal = new Dingo("Dixie", 3, 33.8, Gender.Female);

            // Make Dixie pregnant.
            animal.MakePregnant();

            // Add Dixie to the zoo's animal list.
            comoZoo.AddAnimal(animal);

            // Create Patty.
            animal = new Platypus("Patty", 2, 15.5, Gender.Female);

            // Make Patty pregnant.
            animal.MakePregnant();

            // Add Patty to the zoo's animal list.
            comoZoo.AddAnimal(animal);
      
            // Add Harold to the zoo's animal list.
            comoZoo.AddAnimal(new Hummingbird("Harold", 1, 0.008, Gender.Male));

            // Add the other animals to the zoo.
            comoZoo.AddAnimal(new Ostrich("Corky", 3, 200, Gender.Male));
            comoZoo.AddAnimal(new Eagle("Harpy", 7, 12, Gender.Male));           
            comoZoo.AddAnimal(new Chimpanzee("BoBo", 3, 40, Gender.Male));        
            comoZoo.AddAnimal(new Squirrel("Nutty", 1, 1.3, Gender.Male));
            comoZoo.AddAnimal(new Shark("Smiles", 2, 390, Gender.Female));           
            comoZoo.AddAnimal(new Kangaroo("Kloe", 12, 199, Gender.Female));
       
            // Instantiate a checking account variable.
            Account gregsAccount = new Account();

            // Add the 2500.00 to Greg's savings account. 
                gregsAccount.AddMoney(2500.00m);
       
            // Create Greg.
            Guest greg = new Guest("Greg", 44, 150.35m, WalletColor.Brown, Gender.Male, gregsAccount);

            // Sell Greg a ticket and admit him to the zoo.
            comoZoo.AddGuest(greg, comoZoo.SellTicket(greg));
                        
            // Create Darla.
            Guest darla = new Guest("Darla", 11, 25.50m, WalletColor.Salmon, Gender.Female, greg.Wallet);
    
            // Admitt Darla and add to guest list.
            comoZoo.AddGuest(darla, comoZoo.SellTicket(darla));

            // Return resulting created Zoo.
            return comoZoo;
        }

        /// <summary>
        /// Adds an animal to the zoo.
        /// </summary>
        /// <param name="animal">The animal to add.</param>
        public void AddAnimal(Animal animal)
        {
            this.animals.Add(animal);
        }

        /// <summary>
        /// Adds a guest to the zoo.
        /// </summary>
        /// <param name="guest">The guest to add.</param>
        /// <param name="ticket">A ticket to the zoo.</param>
        public void AddGuest(Guest guest, Ticket ticket)
        {
            // If they have a valid ticket - we will admit.
            if (ticket == null || ticket.IsRedeemed)
            {
                throw new NullReferenceException("Unable to admit guest " + guest.Name + "without a valid ticket.");
            }
            else
            {
                ticket.Redeem();
                this.guests.Add(guest);
            }
        }        

        /// <summary>
        /// Aids a reproducer in giving birth.
        /// </summary>
        /// <param name="reproducer">The reproducer that is to give birth.</param>
        public void BirthAnimal(IReproducer reproducer)
        {
            // Birth animal.
            IReproducer baby = this.b168.BirthAnimal(reproducer);

            // If the baby is an animal...
            if (baby is Animal)
            {
                // Add the baby to the zoo's list of animals.
                this.AddAnimal(baby as Animal);
            }
        }

        /// <summary>
        /// Find an animal based on the animals name..
        /// </summary>
        /// <param name="name">The name of the animal to find.</param>
        /// <returns>The first matching animal.</returns>
        public Animal FindAnimal(string name)
        {
            Animal animal = null;

            // Loop through the zoo's list of animals.
            foreach (Animal a in this.animals)
            {
                // If the type matches...
                if (a.Name == name)
                {
                    // Get the matching animal.
                    animal = a;

                    break;
                }
            }

            return animal;
        }

        /// <summary>
        /// Find an animal based on type.
        /// </summary>
        /// <param name="type">The type of the animal to find.</param>
        /// <returns>The first matching animal.</returns>
        public Animal FindAnimal(Type type)
        {
            Animal animal = null;

            // Loop through the zoo's list of animals.
            foreach (Animal a in this.animals)
            {
                // If the type matches...
                if (a.GetType() == type)
                {
                    // Get the matching animal.
                    animal = a;

                    break;
                }
            }

            return animal;
        }

        /// <summary>
        /// Finds an animal based on type and pregnancy status.
        /// </summary>
        /// <param name="type">The type of the animal to find.</param>
        /// <param name="isPregnant">The pregnancy status of the animal to find.</param>
        /// <returns>The first matching animal.</returns>
        public Animal FindAnimal(Type type, bool isPregnant)
        {
            Animal animal = null;

            // Loop through the zoo's list of animals.
            foreach (Animal a in this.animals)
            {
                // If the type and pregnancy status match...
                if (a.GetType() == type && a.IsPregnant == isPregnant)
                {
                    // Get the matching animal.
                    animal = a;

                    break;
                }
            }

            return animal;
        }

        /// <summary>
        /// Finds a guest based on name.
        /// </summary>
        /// <param name="name">The name of the guest to find.</param>
        /// <returns>The first matching guest.</returns>
        public Guest FindGuest(string name)
        {
            Guest guest = null;

            // Loop through the zoo's list of guests.
            foreach (Guest g in this.guests)
            {
                // If the name matches...
                if (g.Name == name)
                {
                    // Get the matching guest.
                    guest = g;

                    break;
                }
            }

            return guest;
        }

        /// <summary>
        /// Removes an animal from the zoo.
        /// </summary>
        /// <param name="animal">The animal to remove.</param>
        public void RemoveAnimal(Animal animal)
        {
            this.animals.Remove(animal);
        }

        /// <summary>
        /// Removes a guest from the zoo.
        /// </summary>
        /// <param name="guest">A guest to be removed from the zoo.</param>
        public void RemoveGuest(Guest guest)
        {
            this.guests.Remove(guest);
        }

        /// <summary>
        /// Sells a new ticket to a guest.
        /// </summary>
        /// <param name="guest">A guest to the zoo.</param>
        /// <returns>A ticket for admission.</returns>
        public Ticket SellTicket(Guest guest)
        {
            // Call to have guest visit ticket booth. Catch return ticket value.
            Ticket ticket = guest.VisitTicketBooth(this.ticketBooth);

            // Call to visit the information booth.
            guest.VisitInformationBooth(this.informationBooth);

            // Return results.
            return ticket;
        }     
    }
}