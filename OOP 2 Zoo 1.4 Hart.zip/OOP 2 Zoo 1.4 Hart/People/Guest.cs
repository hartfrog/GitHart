﻿using System.Collections.Generic;
using BoothItems;
using Foods;
using MoneyCollectors;
using Reproducers;
using VendingMachines;

namespace People
{
    /// <summary>
    /// The class which is used to represent a guest.
    /// </summary>
    public class Guest : IEater
    {
        /// <summary>
        /// A list of items in a bag.
        /// </summary>
        private List<Item> bag;

        /// <summary>
        /// The age of the guest.
        /// </summary>
        private int age;

        /// <summary>
        /// A checking account.
        /// </summary>
        private IMoneyCollector checkingAccount;
       
        /// <summary>
        /// The gender of a guest.
        /// </summary>
        private Gender gender;

        /// <summary>
        /// The name of the guest.
        /// </summary>
        private string name;

        /// <summary>
        /// The guest's wallet.
        /// </summary>
        private Wallet wallet;

        /// <summary>
        /// Initializes a new instance of the Guest class.
        /// </summary>
        /// <param name="name">The name of the guest.</param>
        /// <param name="age">The age of the guest.</param>
        /// <param name="moneyBalance">The initial amount of money to put into the guest's wallet.</param>
        /// <param name="walletColor">The color of the guest's wallet.</param>
        /// <param name="gender">The gender of the guest.</param>
        /// <param name="checkingAccount">The guests checking account.</param>
        public Guest(string name, int age, decimal moneyBalance, WalletColor walletColor, Gender gender, IMoneyCollector checkingAccount)
        {
            this.age = age;
            this.bag = new List<Item>();
            this.checkingAccount = checkingAccount;
            this.gender = gender;
                    
            this.name = name;
            this.wallet = new Wallet(walletColor, new MoneyPocket());

            // Add money to the wallett.
            this.wallet.AddMoney(moneyBalance);
        }

        /// <summary>
        /// Gets or sets the age of a guest.
        /// </summary>
        public int Age
        {
            get
            {
                return this.age;
            }

            set
            {
                this.age = value;
            }
        }

        /// <summary>
        /// Gets the checking account of a guest.
        /// </summary>
        public IMoneyCollector CheckingAccount
        {
            get
            {
                return this.checkingAccount;
            }
        }

        /// <summary>
        /// Gets the name of the guest.
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }
        }

        /// <summary>
        /// Gets the guests wallet.
        /// </summary>
        public Wallet Wallet
        {
            get
            {
                return this.wallet;
            }
        }

        /// <summary>
        /// Gets the weight of the guest.
        /// </summary>
        public double Weight
        {
            get
            {
                // Confidential.
                return 0.0;
            }
        }

        /// <summary>
        /// Eats the specified food.
        /// </summary>
        /// <param name="food">The food to eat.</param>
        public void Eat(Food food)
        {
            // Eat the food.
        }

        /// <summary>
        /// Feeds the specified eater.
        /// </summary>
        /// <param name="eater">The eater to be fed.</param>
        /// <param name="animalSnackMachine">The animal snack machine from which to buy food.</param>
        public void FeedAnimal(IEater eater, VendingMachine animalSnackMachine)
        {
            // Find food price.
            decimal price = animalSnackMachine.DetermineFoodPrice(eater.Weight);

            // Check food price againt amount currently in the wallet.
            if (this.wallet.MoneyBalance < price)
            {
                // Remove 10 times the amount of the price of the food. 
                this.checkingAccount.RemoveMoney(price * 10); 
            }

            // Get money from wallet.
            decimal payment = this.wallet.RemoveMoney(price);

            // Buy food.
            Food food = animalSnackMachine.BuyFood(payment);

            // Feed animal.
            eater.Eat(food);
        }

        /// <summary>
        /// Visits the information booth.
        /// </summary>
        /// <param name="informationBooth">The information booth.</param>
        public void VisitInformationBooth(GivingBooth informationBooth)
        {
            // Give away a free map.
            Map map = informationBooth.GiveFreeMap();

            // Add map to the bag.
            this.bag.Add(map);

            // Give free coupon book.
            CouponBook couponbook = informationBooth.GiveFreeCouponBook();

            // Add the coupon book to the bag.
            this.bag.Add(couponbook);
        }

        /// <summary>
        /// Gets a ticket from the ticket booth.
        /// </summary>
        /// <param name="ticketBooth">The booth where you receive a ticket.</param>
        /// <returns>A ticket for admission.</returns>
        public Ticket VisitTicketBooth(MoneyCollectingBooth ticketBooth)
        {            
            // Check food price againt amount currently in the wallet.
            if (this.wallet.MoneyBalance < ticketBooth.TicketPrice)
            {
                // Remove 2 times the amount of the price. 
                this.WithdrawMoney(ticketBooth.TicketPrice * 2);
            }

            // Call to make the  payment with remove money method.
            decimal ticketPayment = this.wallet.RemoveMoney(ticketBooth.TicketPrice);

            // Call to actually sell the ticket with a return ticket
            Ticket ticket = ticketBooth.SellTicket(ticketPayment);
            
            // Check food price againt amount currently in the wallet.
            if (this.wallet.MoneyBalance < ticketBooth.WaterBottlePrice)
            {
                // Remove 2 times the amount of the price of the watrebottle. 
                this.WithdrawMoney(ticketBooth.WaterBottlePrice * 2);
            }

            // Call to make the  payment with remove money method.
            decimal waterPayment = this.wallet.RemoveMoney(ticketBooth.WaterBottlePrice);

            // Sell a bottle of water.
            WaterBottle bottle = ticketBooth.SellWaterBottle(waterPayment);

            // Visit the information booth.
            this.bag.Add(bottle);

            // Return results.
            return ticket;
        }

        /// <summary>
        /// Withdraw money from a guest's account.
        /// </summary>
        /// <param name="amount">Amount to withdraw.</param>
        public void WithdrawMoney(decimal amount)
        {
            // Remove passed in amount from the guest's checking account.
             decimal withdrawAmount = this.checkingAccount.RemoveMoney(amount);

            // Add the amount removed to the guest's wallet.
                this.wallet.AddMoney(withdrawAmount);
        }

        /// <summary>
        /// Generates a string representation of a guest.
        /// </summary>
        /// <returns>A string representation of the guest.</returns>
        public override string ToString()
        {
            return string.Format("{0}: {1} [${2} / ${3}]", this.Name, this.Age, this.wallet.MoneyBalance, this.CheckingAccount.MoneyBalance);
        }
    }
}