﻿namespace People
{
    /// <summary>
    /// Enumeration group of wallet colors.
    /// </summary>
    public enum WalletColor
    {
        Black,
        Brown,
        Crimson,
        Indigo,
        Salmon
    }
}
