﻿using System.Collections.Generic;
using BoothItems;

namespace People
{
    /// <summary>
    /// The class which is used to represent a booth.
    /// </summary>
    public abstract class Booth
    {       
        /// <summary>
        /// Contains all of the zoo's items in a booth.
        /// </summary>
        private List<Item> items;
              
        /// <summary>
        /// The employee currently assigned to be the attendant of the booth.
        /// </summary>
        private Employee attendant;

        /// <summary>
        /// Initializes a new instance of the Booth class.
        /// </summary>
        /// <param name="attendant">The employee to be the booth's attendant.</param>
        public Booth(Employee attendant)
        {
            this.attendant = attendant;
            this.items = new List<Item>();
        }

        /// <summary>
        /// Gets an attendant.
        /// </summary>
        protected Employee Attendant
        {
            get
            {
                return this.attendant;
            }
        }

        /// <summary>
        /// Gets the items list.
        /// </summary>
        protected List<Item> Items
        {
            get
            {
                return this.items;
            }
        }                 
    }
}