﻿using MoneyCollectors;

namespace People
{
    /// <summary>
    /// The class which is used to represent an account.
    /// </summary>
    public class Account : IMoneyCollector
    {
        /// <summary>
        /// The current balance.
        /// </summary>
        private decimal moneyBalance;

        /// <summary>
        /// Gets the amount of money on hand.
        /// </summary>
        public decimal MoneyBalance
        {
            get
            {
                return this.moneyBalance;
            }            
        }

        /// <summary>
        /// Adds money to the money balance.
        /// </summary>
        /// <param name="amount">Amount to add.</param>
        public void AddMoney(decimal amount)
        {
            // Increment moneyBalance by passed in amount. 
            this.moneyBalance += amount;
        }

        /// <summary>
        /// Removes money from the money balance.
        /// </summary>
        /// <param name="amount">Amount to remove.</param>
        /// <returns>Amount that was removed.</returns>
        public decimal RemoveMoney(decimal amount)
        {
            decimal amountRemoved = this.moneyBalance -= amount;

            return amountRemoved;
        }
    }
}
