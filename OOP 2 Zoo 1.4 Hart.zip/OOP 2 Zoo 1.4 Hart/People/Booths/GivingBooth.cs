﻿using System;
using BoothItems;

namespace People
{
    /// <summary>
    /// The class used to represent a GivingBooth.
    /// </summary>
    public class GivingBooth : Booth
    {
        /// <summary>
        /// Initializes a new instance of the GivingBooth class.
        /// </summary>
        /// <param name="attendant">The attendant.</param>
        public GivingBooth(Employee attendant)
            : base(attendant)
        {
   

            for (int c = 0; c < 5; c++)
            {
                this.Items.Add(new CouponBook(new DateTime(DateTime.Now.Year, DateTime.Now.Month,DateTime.Now.Day), new DateTime(DateTime.Now.Year + 1), 0.8));
                
            }

            for (int m = 0; m < 10; m++)
            {
               
                this.Items.Add(new Map(0.5, new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day)));
            }
        }

        /// <summary>
        /// Gives away a free coupon book.
        /// </summary>
        /// <returns>A free coupon book.</returns>
        public CouponBook GiveFreeCouponBook()
        {
            // Define and initialize a result variable
            Item freeCouponBook = null;

            // Find a coupon book to give away.
            freeCouponBook = this.Attendant.FindItem(this.Items, typeof(CouponBook));

            // Return the result
            return freeCouponBook as CouponBook;
        }

        /// <summary>
        /// Gives a free map away.
        /// </summary>
        /// <returns>A free map.</returns>
        public Map GiveFreeMap()
        {
            // Define and initialize a result variable
            Item freeMap = null;

            // Find a map to give.
            freeMap = this.Attendant.FindItem(this.Items, typeof(Map));

            // Return the result.
            return freeMap as Map;
        }
    }
}
