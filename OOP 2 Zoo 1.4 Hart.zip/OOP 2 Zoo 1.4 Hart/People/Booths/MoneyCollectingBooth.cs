﻿using System;
using BoothItems;
using MoneyCollectors;

namespace People
{
    /// <summary>
    /// The class which represents a MoneyCollectingBooth.
    /// </summary>
    public class MoneyCollectingBooth : Booth, IMoneyCollector
    {
        /// <summary>
        /// The initial money balance of the booth.
        /// </summary>
        private static readonly decimal InitialMoneyBalance = 100.0m;

        /// <summary>
        /// The price of a ticket.
        /// </summary>
        private decimal ticketPrice;

        /// <summary>
        /// The price of a water bottle.
        /// </summary>
        private decimal waterBottlePrice;

        /// <summary>
        /// A money box.
        /// </summary>
        private IMoneyCollector moneyBox;

        /// <summary>
        /// Initializes a new instance of the MoneyCollectingBooth class.
        /// </summary>
        /// <param name="attendant">An attendant for the booth.</param>
        /// <param name="ticketPrice">The price of a ticket.</param>
        /// <param name="waterBottlePrice">The price of the water bottle.</param>
        /// <param name="moneyBox">The box that holds the money.</param>
        public MoneyCollectingBooth(Employee attendant, decimal ticketPrice, decimal waterBottlePrice, IMoneyCollector moneyBox)
            : base(attendant)
        {
            this.moneyBox = new MoneyBox();
            this.moneyBox.AddMoney(InitialMoneyBalance);
            this.ticketPrice = ticketPrice;
            this.waterBottlePrice = waterBottlePrice;
            
            TimeSpan ts1 = new TimeSpan(365, 0, 0, 0);

            for (int t = 0; t < 5; t++)
            {
                Ticket ticket = new Ticket(ticketPrice, t + 9001, .01);
                Items.Add(ticket);
            }

            for (int w = 0; w < 5; w++)
            {
                WaterBottle waterbottle = new WaterBottle(this.waterBottlePrice, w + 1001, 1);
                Items.Add(waterbottle);
            }
        }

        /// <summary>
        /// Gets the money balance.
        /// </summary>
        public decimal MoneyBalance
        {
            get
            {
                return this.moneyBox.MoneyBalance;
            }
        }

        /// <summary>
        /// Gets the price of a ticket.
        /// </summary>
        public decimal TicketPrice
        {
            get
            {
                return this.ticketPrice;
            }
        }

        /// <summary>
        /// Gets the price of a water bottle.
        /// </summary>
        public decimal WaterBottlePrice
        {
            get
            {
                return this.waterBottlePrice;
            }
        }

        /// <summary>
        /// Add money to the collecting booth.
        /// </summary>
        /// <param name="amount">Amount of money to add.</param>
        public void AddMoney(decimal amount)
        {
            // Adds money.
            this.moneyBox.AddMoney(amount);
        }

        /// <summary>
        /// Removes money.
        /// </summary>
        /// <param name="amount">Amount of money to remove.</param>
        /// <returns>Amount removed.</returns>
        public decimal RemoveMoney(decimal amount)
        {
            decimal amountRemoved = this.moneyBox.RemoveMoney(amount);

            return amountRemoved;
        }

        /// <summary>
        /// Sells a ticket.
        /// </summary>
        /// <param name="payment">Amount of money paid for a ticket.</param>
        /// <returns>A ticket for admission.</returns>
        public Ticket SellTicket(decimal payment)
        {
            // Define and intialize a result variable.
            Item ticket = null;

            // If guest has enough money to pay the full fare.
            if (payment >= this.ticketPrice)
            {
                // Have the attendant find a ticket in the list of tickets.
                ticket = this.Attendant.FindItem(this.Items, typeof(Ticket));

                // If a ticket was found and returned.
                if (ticket != null)
                {
                    // Add payment to the booths money balance.
                    this.moneyBox.AddMoney(payment);
                }
            }

            // return ticket.
            return ticket as Ticket;
        }

        /// <summary>
        /// Sells a bottle of water.
        /// </summary>
        /// <param name="payment">Amount of money paid for a water bottle.</param>
        /// <returns>A water bottle.</returns>
        public WaterBottle SellWaterBottle(decimal payment)
        {
            // Define and initialize a result variable
            Item waterBottle = null;

            // If guest has enough money to pay the full fare.
            if (payment >= this.WaterBottlePrice)
            {
                // Have the attendant find a ticket in the list of tickets.
                waterBottle = this.Attendant.FindItem(this.Items, typeof(WaterBottle));

                // If a ticket was found and returned.
                if (waterBottle != null)
                {
                    // Add payment to the booths money balance.
                    this.AddMoney(payment);
                }
            }

            // Return results.
            return waterBottle as WaterBottle;
        }
    }
}
