﻿using System;
using Animals;
using People;
using Reproducers;
using Zoos;

namespace ZooConsole
{
    /// <summary>
    /// The class which is used as a ConsoleHelper.
    /// </summary>
    internal static class ConsoleHelper
    {   
        /// <summary>
        /// Process the show console command.
        /// </summary>
        /// <param name="zoo">The zoo containing the object to show.</param>
        /// <param name="type">The object type to show.</param>
        /// <param name="name">The name of the object.</param>
        public static void ProcessShowCommand(Zoo zoo, string type, string name)
        {
            string uppercaseName = ConsoleUtil.InitialUpper(name);

            switch (type)
            {
                case "animal":
                    ConsoleHelper.ShowAnimal(zoo, uppercaseName);

                    break;
                case "guest":
                    ConsoleHelper.ShowGuest(zoo, uppercaseName);

                    break;
                default:
                    Console.WriteLine("Unknown type entered. Only animals and guests can be shown.");

                    break;
            }
        }

        /// <summary>
        /// Sets the temperature of the birthing room.
        /// </summary>
        /// <param name="zoo">A zoo to have its temperature set.</param>
        /// <param name="temp">The temperature to set.</param>
        public static void SetTemperature(Zoo zoo, string temp)
        {
            double newTemp = double.Parse(temp);
            double previousTemp = zoo.BirthingRoomTemperature;

            zoo.BirthingRoomTemperature = newTemp;

            Console.WriteLine(string.Format("Previous temperature: {0:0.0}", newTemp));
            Console.WriteLine(string.Format("New temperature set at: {0:0.0}", zoo.BirthingRoomTemperature));
        }

        /// <summary>
        /// Shows an animal in the console.
        /// </summary>
        /// <param name="zoo">A zoo where the animal is.</param>
        /// <param name="name">The animal name.</param>
        private static void ShowAnimal(Zoo zoo, string name)
        {
            Animal animal = zoo.FindAnimal(name);
            if (animal != null)
            {
                Console.WriteLine(string.Format("The following animal was found: {0}", animal));
            }
            else
            {
                Console.WriteLine(name + " could not be found.");
            }
        }

        /// <summary>
        /// Shows a guest in the console.
        /// </summary>
        /// <param name="zoo">The zoo where the guest is located.</param>
        /// <param name="name">The name of the guest to show.</param>
        private static void ShowGuest(Zoo zoo, string name)
        {
            Guest guest = zoo.FindGuest(name);
            if (guest != null)
            {
                Console.WriteLine(string.Format("The following guest was found: {0}", guest));
            }
            else
            {
                Console.WriteLine(name + " could not be found.");
            }
        }
    }
}
