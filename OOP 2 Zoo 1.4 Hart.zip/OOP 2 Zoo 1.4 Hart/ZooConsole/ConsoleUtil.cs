﻿using System;
using Animals;

namespace ZooConsole
{
    /// <summary>
    /// The class which is used as a console utility.
    /// </summary>
    internal static class ConsoleUtil
    {
        /// <summary>
        /// Returns a string with the first letter capitalized.
        /// </summary>
        /// <param name="value">The string to capitalize.</param>
        /// <returns>A string value.</returns>
        public static string InitialUpper(string value)
        {
            return value != null && value.Length > 0 ? char.ToUpper(value[0]) + value.Substring(1) : null;
        }
    }
}
