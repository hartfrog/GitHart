﻿using System;
using Zoos;

namespace ZooConsole
{
    /// <summary>
    /// The class which is used to manage interaction with the console.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    public class Program
    {
        /// <summary>
        /// Serves as the entry-point for the console application.
        /// </summary>
        /// <param name="args">Window commands.</param>
        public static void Main(string[] args)
        {
            // Set window title.
            Console.Title = "Object-Oriented Programming 2: Zoo";

            // Display introductory message.
            Console.WriteLine("Welcome to the Como Zoo!");

            // Instantiate a zoo.
            Zoo zoo = Zoo.NewZoo();

            bool exit = false;

            string command;

            try
            {
                while (!exit)
                {
                    Console.Write("> ");

                    command = Console.ReadLine();

                    command = command.ToLower().Trim();

                    string[] commandWords = command.ToLower().Trim().Split();

                    switch (commandWords[0])
                    {
                        case "exit":
                            exit = true;
                            break;

                        case "restart":
                            zoo = Zoo.NewZoo();
                            Console.WriteLine("A new Como Zoo has been recreated.");
                            break;

                        case "help":
                            Console.WriteLine("Commands:");
                            Console.WriteLine("HELP: Shows a list of known commands");
                            Console.WriteLine("EXIT: Exits the application");
                            Console.WriteLine("RESTART:  Recreates the Como Zoo");
                            Console.WriteLine("SHOW ANIMAL: locates an animal by its first name. i.e. (SHOW ANIMAL DOLLY)");
                            Console.WriteLine("SHOW GUEST: locates a guest by their first name. i.e. (SHOW GUEST GREG)");
                            Console.WriteLine("TEMP ##F°: Sets the current temperature of the birthing room. i.e (TEMP 70)");
                            break;

                        case "temp":
                            try
                            {
                                ConsoleHelper.SetTemperature(zoo, commandWords[1]);
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("Enter a parameter for temperature");
                            }

                            break;

                        case "show":
                            try
                            {
                                ConsoleHelper.ProcessShowCommand(zoo, commandWords[1], commandWords[2]);
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("Enter a parameter for [animal] name and [guest] name");
                            }

                            break;

                        default:
                            Console.WriteLine("Invalid Command Entered");

                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
