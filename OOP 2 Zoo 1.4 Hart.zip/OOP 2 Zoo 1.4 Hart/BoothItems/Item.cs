﻿namespace BoothItems
{
    /// <summary>
    /// The class which represents items in a booth.
    /// </summary>
    public class Item
    {        
        /// <summary>
        /// The weight of an item.
        /// </summary>
        private double weight;

        /// <summary>
        /// Initializes a new instance of the Item class.
        /// </summary>
        /// <param name="weight">The weight of an item.</param>
        public Item(double weight)
        {            
            this.weight = weight;
        }
    
        /// <summary>
        /// Gets the weight of an item.
        /// </summary>
        public double Weight
        {
            get
            {
                return this.weight;
            }
        }
    }
}
