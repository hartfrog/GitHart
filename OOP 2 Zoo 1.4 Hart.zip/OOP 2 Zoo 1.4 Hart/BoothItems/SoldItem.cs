﻿namespace BoothItems
{
    /// <summary>
    /// The class used to represent sold items.
    /// </summary>
    public class SoldItem : Item
    {
        /// <summary>
        /// The price of an item.
        /// </summary>
        private decimal price;

        /// <summary>
        /// Initializes a new instance of the SoldItem class.
        /// </summary>
        /// <param name="price">The price of a sold item.</param>
        /// <param name="weight">The weight of a sold item.</param>
        public SoldItem(decimal price, double weight)
           : base(weight)
        {
            this.price = price;            
        }
    }
}
