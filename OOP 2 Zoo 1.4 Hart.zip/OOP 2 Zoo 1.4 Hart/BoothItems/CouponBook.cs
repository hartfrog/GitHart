﻿using System;

namespace BoothItems
{
    /// <summary>
    /// The class that represents a book of coupons.
    /// </summary>
    public class CouponBook : Item
    {
        /// <summary>
        /// The date and time a coupon item was made.
        /// </summary>
        private DateTime dateMade;

        /// <summary>
        /// The date and item the coupon item expires.
        /// </summary>
        private DateTime dateExpired;

        /// <summary>
        /// Initializes a new instance of the CouponBook class.
        /// </summary>
        /// <param name="dateMade">The date the coupon item was made.</param>
        /// <param name="dateExpired">The date the coupon item expires.</param>
        /// <param name="weight">The weight of the coupon book item.</param>
        public CouponBook(DateTime dateMade, DateTime dateExpired, double weight)
            : base(weight)
        {
            this.dateMade = DateTime.Now;
            this.dateExpired = dateExpired;
        }

        /// <summary>
        /// Gets the date the coupon item was made.
        /// </summary>
        public DateTime DateMade
        {
            get
            {
                return this.dateMade;
            }
        }

        /// <summary>
        /// Gets the date the coupon item was made.
        /// </summary>
        public DateTime DateExpired
        {
            get
            {
                return this.dateMade + new TimeSpan(365, 0, 0, 0);
            }
        }
    }
}
