﻿namespace BoothItems
{
    /// <summary>
    /// The class which represents a ticket.
    /// </summary>
    public class Ticket : SoldItem
    {
        /// <summary>
        /// Indicates weather or not a ticket is redeemable.
        /// </summary>
        private bool isRedeemed;
     
        /// <summary>
        /// The serial number of a ticket.
        /// </summary>
        private int serialNumber;
       
        /// <summary>
        /// Initializes a new instance of the Ticket class.
        /// </summary>
        /// <param name="price">The price of a ticket.</param>
        /// <param name="serialNumber">The serial number of a ticket.</param>
        /// <param name="weight">The weight of a ticket.</param>
        public Ticket(decimal price, int serialNumber, double weight)
            : base(0, weight)
        { 
            this.serialNumber = serialNumber;
        }

        /// <summary>
        /// Gets a value indicating whether a ticket has been redeemed or not.
        /// </summary>
        public bool IsRedeemed
        {
            get
            {
                return this.isRedeemed;
            }
        }

        /// <summary>
        /// Gets the serial number of a ticket.
        /// </summary>
        public int SerialNumber
        {
            get
            {
                return this.serialNumber;
            }
        }

        /// <summary>
        /// Redeem a ticket.
        /// </summary>
        public void Redeem()
        {
            // Redeem a ticket.
            this.isRedeemed = true;        
        }
    }
}
