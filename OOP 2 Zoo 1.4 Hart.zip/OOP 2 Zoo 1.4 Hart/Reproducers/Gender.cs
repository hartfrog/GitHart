﻿namespace Reproducers
{
    /// <summary>
    /// A class used to represent gender.
    /// </summary>
    public enum Gender
    {
        Female,
        Male,        
    }
}
