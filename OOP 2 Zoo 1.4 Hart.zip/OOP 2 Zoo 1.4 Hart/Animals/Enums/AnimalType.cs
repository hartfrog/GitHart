﻿namespace Animals
{
    /// <summary>
    /// A list of animal types.
    /// </summary>
    public enum AnimalType
    {
        Chimpanzee,
        Dingo,
        Eagle,
        Hummingbird,
        Kangaroo,
        Ostrich,
        Platypus,
        Shark,
        Squirrel
    }
}
