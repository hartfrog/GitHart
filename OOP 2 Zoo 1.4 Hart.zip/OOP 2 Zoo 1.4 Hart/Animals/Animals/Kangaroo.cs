﻿using Reproducers;

namespace Animals
{
    /// <summary>
    /// The class used to represent a Kangaroo.
    /// </summary>
    public class Kangaroo : Mammal
    {
        /// <summary>
        /// Initializes a new instance of the Kangaroo class.
        /// </summary>
        /// <param name="name">Name of the Kangaroo.</param>
        /// <param name="age">Age of the Kangaroo.</param>
        /// <param name="weight">Weight of the Kangaroo.</param>
        /// <param name="gender">The gender of the Kangaroo.</param>
        public Kangaroo(string name, int age, double weight, Gender gender)
            : base(name, age, weight, gender)
        {
            this.BabyWeightPercentage = 13;
        }

        /// <summary>
        /// Moves by jumping or hopping.
        /// </summary>
        public override void Move()
        {
            // Jumping or hopping.         
        }
    }
}
