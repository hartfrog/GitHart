﻿using Reproducers;

namespace Animals
{
    /// <summary>
    /// The class used to represent an Ostrich.
    /// </summary>
    public sealed class Ostrich : Bird, IHatchable
    {
        /// <summary>
        /// Initializes a new instance of the Ostrich class.
        /// </summary>
        /// <param name="name">Name of the Ostrich.</param>
        /// <param name="age">Age of the Ostrich.</param>
        /// <param name="weight">Weight of the Ostrich.</param>
        /// <param name="gender">The gender of the Ostrich.</param>
        public Ostrich(string name, int age, double weight, Gender gender)
            : base(name, age, weight, gender)
        {
            this.BabyWeightPercentage = 30;
        }

        /// <summary>
        /// Moves by running.
        /// </summary>
        public override void Move()
        {
            // Running on two legs.
        }
    }
}
