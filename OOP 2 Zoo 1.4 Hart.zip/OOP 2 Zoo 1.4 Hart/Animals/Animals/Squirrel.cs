﻿using Reproducers;

namespace Animals
{
    /// <summary>
    /// The class used to represent a Squirrel.
    /// </summary>
    public class Squirrel : Mammal
    {
        /// <summary>
        /// Initializes a new instance of the Squirrel class.
        /// </summary>
        /// <param name="name">Name of the squirrel.</param>
        /// <param name="age">Age of the squirrel.</param>
        /// <param name="weight">Weight of the squirrel.</param>
        /// <param name="gender">The gender of the squirrel.</param>
        public Squirrel(string name, int age, double weight, Gender gender)
            : base(name, age, weight, gender)
        {
            this.BabyWeightPercentage = 17;
        }

        /// <summary>
        /// Moves by scurry and climb.
        /// </summary>
        public override void Move()
        {
            // Scurry and climb.
        }
    }
}
