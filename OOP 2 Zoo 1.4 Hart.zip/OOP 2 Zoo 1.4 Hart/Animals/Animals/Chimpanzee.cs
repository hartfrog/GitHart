﻿using Reproducers;

namespace Animals
{
   /// <summary>
   /// The class used to represent a Chimpanzee.
   /// </summary>
    public class Chimpanzee : Mammal
    {
        /// <summary>
        /// Initializes a new instance of the Chimpanzee class.
        /// </summary>
        /// <param name="name">Name of the Chimpanzee.</param>
        /// <param name="age">Age of the Chimpanzee.</param>
        /// <param name="weight">Weight of the Chimpanzee.</param>
        /// <param name="gender">The gender of the animal.</param>
        public Chimpanzee(string name, int age, double weight, Gender gender)
            : base(name, age, weight, gender)
        {
            this.BabyWeightPercentage = 10;
        }
    }
}
