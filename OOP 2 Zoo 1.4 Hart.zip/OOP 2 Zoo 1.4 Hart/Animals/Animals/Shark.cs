﻿using Reproducers;

namespace Animals
{
    /// <summary>
    /// The class used to represent a shark.
    /// </summary>
    public class Shark : Fish
    {
        /// <summary>
        /// Initializes a new instance of the Shark class.
        /// </summary>
        /// <param name="name">Name of the shark.</param>
        /// <param name="age">Age of the shark.</param>
        /// <param name="weight">Weight of the shark.</param>
        /// <param name="gender">The gender of the shark.</param>
        public Shark(string name, int age, double weight, Gender gender)
            : base(name, age, weight, gender)
        {
            this.BabyWeightPercentage = 18;
        }
    }
}
