﻿using System;
using System.Windows;
using System.Windows.Media;
using Animals;
using BirthingRooms;
using BoothItems;
using People;
using Zoos;
using Reproducers;

namespace ZooScenario
{
    /// <summary>
    /// Contains interaction logic for MainWindow.xaml.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Minnesota's Como Zoo.
        /// </summary>
        private Zoo comoZoo;

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();

#if DEBUG
            this.Title += " [DEBUG]";
#endif
        }
        
        /// <summary>
        /// Admits guests to the zoo.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void admitGuestButton_Click(object sender, RoutedEventArgs e)
        {
                Account ethelsAccount = new Account();
                ethelsAccount.AddMoney(30.00m);

                // Instatiate guest Ethel.
                Guest guest = new Guest("Ethel", 42, 30.00m, WalletColor.Salmon, Gender.Female, ethelsAccount);
            try
            {
                Ticket ticket = this.comoZoo.SellTicket(guest);

                this.comoZoo.AddGuest(guest, ticket);

                // Add new guest to the main window guest list.
                this.PopulateGuestListBox();
            }            
            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Feeds the animals in the zoo.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void feedAnimalbutton_Click(object sender, RoutedEventArgs e)
        {

            // Assign selcted value to guest and animal.
            Guest guest = this.guestListBox.SelectedItem as Guest;
            Animal animal = animal = this.animalListBox.SelectedItem as Animal;

            if (guest != null && animal != null)
            {
                
              guest.FeedAnimal(animal, this.comoZoo.AnimalSnackMachine);

                // Repopulate Lists
                this.PopulateAnimalListBox();

                // Repopulate Lists
                this.PopulateGuestListBox();
            }
            else
            {
                MessageBox.Show(string.Format("Please slect a guest and an animal"), "Confirmation", MessageBoxButton.OK);
            }
        }

        /// <summary>
        /// Increase the birthing room temperature.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void increaseTemperatureButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {             
                // Increase the birthing room temperature by an increment of one.  
                this.comoZoo.BirthingRoomTemperature++;

                // Adjust display to refect temperature changes.
                this.ConfigureBirthingRoomControls();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("The zoo must be created before the temperature can be set.");
            }
        }

        /// <summary>
        /// Decrease the birthing room temperature.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void decreaseTemperatureButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {         
                // Increase the birthing room temperature by an increment of one.  
                this.comoZoo.BirthingRoomTemperature--;

                // Adjust display to refect temperature changes.
                this.ConfigureBirthingRoomControls();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("The zoo must be created before the temperature can be set.");
            }
        }

        /// <summary>
        /// Configures the temperature for the birthing room.
        /// </summary>
        private void ConfigureBirthingRoomControls()
        {

            // Set the temp label to show with one decimal place and temperature symbol.
            this.temperatureLabel.Content = string.Format("{0:0.0°F}", this.comoZoo.BirthingRoomTemperature);

            // The the control border bar to a level reflective of the temperature in the birthing room..
            this.temperatureBorder.Height = this.comoZoo.BirthingRoomTemperature * 2;

            

            // Set color to reflect temperature levels of the birthing room.
            double colorLevel = ((this.comoZoo.BirthingRoomTemperature - BirthingRoom.MinTemperature) * 255) / (BirthingRoom.MaxTemperature - BirthingRoom.MinTemperature);

            this.temperatureBorder.Background = new SolidColorBrush(Color.FromRgb(
                Convert.ToByte(colorLevel),
                Convert.ToByte(255 - colorLevel),
                Convert.ToByte(255 - colorLevel)));
        }

        /// <summary>
        /// Populates the guest list box.
        /// </summary>
        private void PopulateGuestListBox()
        {
            this.guestListBox.ItemsSource = null;
            this.guestListBox.ItemsSource = this.comoZoo.Guests;
        }

        /// <summary>
        /// Populates the list box.
        /// </summary>
        private void PopulateAnimalListBox()
        {
            this.animalListBox.ItemsSource = null;
            this.animalListBox.ItemsSource = this.comoZoo.Animals;
        }

        /// <summary>
        /// Creates a zoo and related objects.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void window_Loaded(object sender, RoutedEventArgs e)
        {          
            this.comoZoo = Zoo.NewZoo();

            this.ConfigureBirthingRoomControls();

            this.PopulateAnimalListBox();

            this.PopulateGuestListBox();
        }      
    }
}