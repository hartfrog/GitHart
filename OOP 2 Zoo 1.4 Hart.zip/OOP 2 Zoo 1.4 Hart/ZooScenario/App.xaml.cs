﻿using System.Windows;

namespace ZooScenario
{
    /// <summary>
    /// Contains interaction logic for App.xaml.
    /// </summary>
    public partial class App : Application
    {
    }
}