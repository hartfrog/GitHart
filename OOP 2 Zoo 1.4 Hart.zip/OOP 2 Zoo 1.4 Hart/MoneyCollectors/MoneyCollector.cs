﻿namespace MoneyCollectors
{
    /// <summary>
    /// The class used to represent the money collectors.
    /// </summary>
    public abstract class MoneyCollector : IMoneyCollector
    {
        /// <summary>
        /// The amount of money on hand.
        /// </summary>
        private decimal moneyBalance;

        /// <summary>
        /// Gets the money balance.
        /// </summary>
        public decimal MoneyBalance
        {
            get
            {
                return this.moneyBalance;
            }
        }

        /// <summary>
        /// Adds a specified amount of money.
        /// </summary>
        /// <param name="amount">The amount of money to add.</param>
        public void AddMoney(decimal amount)
        {
            this.moneyBalance += amount;
        }

        /// <summary>
        /// Removes a specified amount of money.
        /// </summary>
        /// <param name="amount">The amount of money to remove.</param>
        /// <returns>The amount of money removed.</returns>
        public virtual decimal RemoveMoney(decimal amount)
        {
            decimal amountRemoved;

            // If there is enough money...
            if (this.moneyBalance >= amount)
            {
                // Return the requested amount.
                amountRemoved = amount;
            }
            else
            {
                // Return all remaining money.
                amountRemoved = this.moneyBalance;
            }

            // Subtract the amount removed.
            this.moneyBalance -= amountRemoved;

            return amountRemoved;
        }
    }
}
