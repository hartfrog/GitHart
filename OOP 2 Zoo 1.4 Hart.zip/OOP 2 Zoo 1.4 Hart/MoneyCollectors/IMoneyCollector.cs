﻿namespace MoneyCollectors
{
    /// <summary>
    /// Interface used to represent money collecting.
    /// </summary>
    public interface IMoneyCollector
    {
        /// <summary>
        /// Gets the amount of money on hand.
        /// </summary>
        decimal MoneyBalance { get; }

        /// <summary>
        /// Adds money.
        /// </summary>
        /// <param name="amount">An amount of money to add.</param>
        void AddMoney(decimal amount);

        /// <summary>
        /// Removes money.
        /// </summary>
        /// <param name="amount">Amount of money removed.</param>
        /// <returns>Amount removed.</returns>
        decimal RemoveMoney(decimal amount);
    }
}
