﻿namespace MoneyCollectors
{
    /// <summary>
    /// The class used to represent a MoneyBox.
    /// </summary>
    public class MoneyBox : MoneyCollector
    {
        /// <summary>
        /// Removes money.
        /// </summary>
        /// <param name="amount">Amount to remove.</param>
        /// <returns>Amount that was removed.</returns>
        public override decimal RemoveMoney(decimal amount)
        {
            // Unlocks the money box.
            this.Unlock();

            // Removes the amount of money.
            decimal result = base.RemoveMoney(amount);

            // Locks the money box.
            this.Lock();

            // Return results.
            return result;
        }

        /// <summary>
        /// Locks the money box.
        /// </summary>
        private void Lock()
        {
        }

        /// <summary>
        /// Unlocks the money box.
        /// </summary>
        private void Unlock()
        {
        }     
    }
}
