﻿namespace MoneyCollectors
{
    /// <summary>
    /// The class used which represent a MoneyPocket.
    /// </summary>
    public class MoneyPocket : MoneyCollector
    {
        /// <summary>
        /// Removes money.
        /// </summary>
        /// <param name="amount">Amount to be removed.</param>
        /// <returns>An amount to remove.</returns>
        public override decimal RemoveMoney(decimal amount)
        {
            // Unfold the money pocket.
            this.Unfold();

            // Removes the amount of money.
            decimal result = base.RemoveMoney(amount);

            // Closes the money pocket.
            this.Fold();

            // Return results.
            return result;
        }

        /// <summary>
        /// Folds the money pocket.
        /// </summary>
        private void Fold()
        {
        }

        /// <summary>
        /// Unfolds the money pocket.
        /// </summary>
        private void Unfold()
        {
        }
    }
}
