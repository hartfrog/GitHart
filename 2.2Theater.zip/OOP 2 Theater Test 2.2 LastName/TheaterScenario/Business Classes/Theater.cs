﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterScenario
{
    /// <summary>
    /// The class which is used to represent a theater.
    /// </summary>
    public class Theater
    {
        /// <summary>
        /// The theater's current list of movies.
        /// </summary>
        public List<Movie> Movies;

        /// <summary>
        /// The name of the theater.
        /// </summary>
        private string name;

        /// <summary>
        /// The theater's screening room 1.
        /// </summary>
        private ScreeningRoom screeningRoom;

        /// <summary>
        /// Gets or sets the name of the theater.
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
            }
        }

        /// <summary>
        /// Gets or sets screening room 1.
        /// </summary>
        public ScreeningRoom ScreeningRoom
        {
            get
            {
                return this.screeningRoom;
            }

            set
            {
                this.screeningRoom = value;
            }
        }
    }
}