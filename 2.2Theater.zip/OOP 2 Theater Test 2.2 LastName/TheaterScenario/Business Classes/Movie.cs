﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterScenario
{
    /// <summary>
    /// The class which is used to represent a theater.
    /// </summary>
    public class Movie
    {
        /// <summary>
        /// The indicator of whether or not the movie is 3D.
        /// </summary>
        public bool Is3d;

        /// <summary>
        /// The MPAA rating of the movie.
        /// </summary>
        public string Rating;

        /// <summary>
        /// The runtime of the movie (in minutes).
        /// </summary>
        public int Runtime;

        /// <summary>
        /// The title of the movie.
        /// </summary>
        public string Title;
    }
}